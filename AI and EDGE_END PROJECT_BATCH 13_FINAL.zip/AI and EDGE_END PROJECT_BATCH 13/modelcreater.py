import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, classification_report

# Load the dataset
file_path = "Gas_Dataset.csv"  # Update the path if needed
df = pd.read_csv(file_path)

# Check for missing values
if df.isnull().sum().sum() == 0:
    print("No missing values found.")
else:
    print("Dataset contains missing values. Consider handling them before training.")

# Encode Gas labels
df["Gas"] = df["Gas"].astype("category").cat.codes

# Define features & target
X = df.iloc[:, 1:-1].values  # Sensor values
y = df["Gas"].values  # Encoded gas type

# Normalize sensor values
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

# Define the TensorFlow model
model = keras.Sequential([
    layers.Dense(256, activation='relu', kernel_regularizer=regularizers.l2(1e-4), input_shape=(X.shape[1],)),
    layers.BatchNormalization(),
    layers.Dropout(0.1),

    layers.Dense(128, activation='relu', kernel_regularizer=regularizers.l2(1e-4)),
    layers.BatchNormalization(),
    layers.Dropout(0.1),

    layers.Dense(64, activation='relu', kernel_regularizer=regularizers.l2(1e-4)),
    layers.BatchNormalization(),
    layers.Dropout(0.05),

    layers.Dense(len(np.unique(y)), activation='softmax')
])

# Compile the model
model.compile(optimizer=keras.optimizers.Adam(learning_rate=0.0005, weight_decay=1e-6),
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train the model
epochs = 50
history = model.fit(X_train, y_train, epochs=epochs, batch_size=32, validation_data=(X_test, y_test), verbose=1)

# Evaluate the model
y_pred = np.argmax(model.predict(X_test), axis=1)
accuracy = accuracy_score(y_test, y_pred)
print(f"Neural Network Accuracy: {accuracy:.4f}")
print(f"Neural Network Classification Report:\n{classification_report(y_test, y_pred)}")

# Convert model to TensorFlow Lite with quantization
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
tflite_model = converter.convert()

# Save the TFLite model
with open("gas_classifier_n.tflite", "wb") as f:
    f.write(tflite_model)

print("TensorFlow Lite model saved as 'gas_classifier.tflite'")