import numpy as np
import tflite_runtime.interpreter as tflite
import pandas as pd
import json
import paho.mqtt.client as mqtt
from sklearn.preprocessing import MinMaxScaler

# Load dataset for scaling
file_path = "Gas_Dataset.csv"
df = pd.read_csv(file_path)

# Prepare MinMaxScaler
X = df.iloc[:, 1:-1].values
scaler = MinMaxScaler()
scaler.fit(X)

# Gas labels
df["Gas"] = df["Gas"].astype("category")
gas_labels = df["Gas"].cat.categories.tolist()

# Load TFLite model
interpreter = tflite.Interpreter(model_path="gas_classifier_n.tflite")
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

# MQTT setup
BROKER = "localhost"
TOPIC_SUB = "sensor/data"
TOPIC_PUB = "sensor/classified"

client = mqtt.Client()
client.connect(BROKER, 1883, 60)

def on_message(client, userdata, msg):
    try:
        received_data = json.loads(msg.payload.decode())

        # Extract only numerical sensor values (ignore predicted class if exists)
        numeric_values = [v for k, v in received_data.items() if isinstance(v, (int, float))]

        if not numeric_values:
            print("No valid numeric sensor data received.")
            return

        # Convert to NumPy array
        raw_values = np.array(numeric_values, dtype=np.float32).reshape(1, -1)

        # Scale input
        scaled_values = scaler.transform(raw_values)

        # Run inference
        interpreter.set_tensor(input_details[0]['index'], scaled_values.astype(np.float32))
        interpreter.invoke()
        output_data = interpreter.get_tensor(output_details[0]['index'])

        # Get predicted class
        predicted_class_index = np.argmax(output_data)
        predicted_class_name = gas_labels[predicted_class_index]

        # Add prediction to the published data
        received_data["Predicted_Gas"] = predicted_class_name

        # Publish updated data
        client.publish(TOPIC_PUB, json.dumps(received_data))
        print(f"Published classified data: {received_data}")

    except Exception as e:
        print(f"Error processing message: {e}")

mqtt_client = mqtt.Client()
mqtt_client.on_message = on_message
mqtt_client.connect(BROKER, 1883, 60)
mqtt_client.subscribe(TOPIC_SUB)
mqtt_client.loop_forever()
