from flask import Flask, render_template, jsonify, request
import paho.mqtt.client as mqtt
import json
import csv
import os
from datetime import datetime
from collections import deque

app = Flask(__name__)

# MQTT Configuration
BROKER = "localhost"
TOPIC = "sensor/classified"  # Matches inference.py

# Data storage
sensor_data = {"timestamp": "", "values": {}, "predicted_gas": ""}
data_history = deque(maxlen=50)  # Store last 50 readings
valve_state = "open"  # Simulated valve state

# Dangerous gases based on classification
DANGEROUS_GASES = {"Smoke", "Mixed"}

# Log file
LOG_FILE = "data_log.csv"
if not os.path.exists(LOG_FILE):
    with open(LOG_FILE, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Timestamp", "Sensor Data", "Predicted Gas"])

# MQTT Callback
def on_message(client, userdata, msg):
    global sensor_data
    try:
        data = json.loads(msg.payload.decode())
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Extract sensor values and classification result
        sensor_values = {k: v for k, v in data.items() if isinstance(v, (int, float))}
        predicted_gas = data.get("Predicted_Gas", "NoGas")  # Default to NoGas

        # Update latest data
        sensor_data = {
            "timestamp": timestamp,
            "values": sensor_values,
            "predicted_gas": predicted_gas,
        }

        # Store in history
        data_history.append(sensor_data)

        # Log to file
        with open(LOG_FILE, mode="a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([timestamp, json.dumps(sensor_values), predicted_gas])

        print(f"Logged: {sensor_values} -> {predicted_gas}")

    except Exception as e:
        print(f"Error processing message: {e}")

# Flask Routes
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/data")
def get_data():
    return jsonify(list(data_history))

@app.route("/mobile")
def mobile():
    return render_template("mobile.html")


@app.route("/toggle_valve", methods=["POST"])
def toggle_valve():
    global valve_state
    valve_state = "closed" if valve_state == "open" else "open"
    return jsonify({"valve_state": valve_state})

@app.route("/valve_state")
def get_valve_state():
    return jsonify({"valve_state": valve_state})

@app.route("/dangerous_gas")
def dangerous_gas():
    """Check if the last recorded gas is dangerous"""
    last_entry = data_history[-1] if data_history else {"predicted_gas": "NoGas"}
    is_dangerous = last_entry["predicted_gas"] in DANGEROUS_GASES
    return jsonify({"is_dangerous": is_dangerous})

# MQTT Setup
client = mqtt.Client()
client.on_message = on_message
client.connect(BROKER, 1883, 60)
client.subscribe(TOPIC)
client.loop_start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
