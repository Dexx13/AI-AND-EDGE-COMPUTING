import paho.mqtt.client as mqtt
import pandas as pd
import time
import json
import random

# Load dataset
df = pd.read_csv("Gas_Dataset.csv")  # Ensure this file is in the same directory

# Extract only sensor data columns (Skipping Serial Number & Gas Label)
no_gas_data = df.iloc[:1600, 1:-1]
perfume_data = df.iloc[1600:3200, 1:-1]
smoke_data = df.iloc[3200:4800, 1:-1]
mixed_data = df.iloc[4800:, 1:-1]

# MQTT Configuration
BROKER = "localhost"
TOPIC = "sensor/data"

# MQTT Setup
client = mqtt.Client()
client.connect(BROKER, 1883, 60)

counter = 0  # Track time in seconds
while True:
    if counter % 15 == 0 and counter > 0:
        gas_choice = random.choice([perfume_data, smoke_data, mixed_data])
        sensor_values = gas_choice.sample(n=1).to_dict(orient="records")[0]
        print("Published Random Gas:", sensor_values)
    else:
        sensor_values = no_gas_data.iloc[counter % 1600].to_dict()
        print("Published NoGas:", sensor_values)

    # Convert to JSON format
    formatted_data = {key: int(value) for key, value in sensor_values.items()}
    json_data = json.dumps(formatted_data)

    # Publish data
    client.publish(TOPIC, json_data)

    time.sleep(1)
    counter += 1
